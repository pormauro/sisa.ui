export const BASE_URL = 'https://sistema.depros.com.ar';
export const MAX_FILE_SIZE = 1 * 1024 * 1024; // 1 MB